"""Top-level package for eos_workflow."""

__author__ = """Weiguo Jing"""
__email__ = 'jingslaw163@gmail.com'
__version__ = '0.1.0'
