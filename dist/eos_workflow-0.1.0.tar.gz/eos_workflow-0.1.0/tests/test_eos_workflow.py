#!/usr/bin/env python

"""Tests for `eos_workflow` package."""


import unittest

from eos_workflow import eos_workflow


class TestEos_workflow(unittest.TestCase):
    """Tests for `eos_workflow` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
