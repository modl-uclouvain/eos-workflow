.. include:: ../AUTHORS.rst
