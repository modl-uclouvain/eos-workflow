# setup.py
from setuptools import setup, find_packages

setup(
    name='eos_jobflow',                  # Name of your package
    version='0.1',                      # Version
    packages=find_packages(),           # Automatically find packages
    install_requires=[                  # List dependencies here
        'abipy', 'atomate2', 'jobflow_remote'
    ],
    author='weiguo jing',
    author_email='jingslaw163@gmail.com',
    description='A description of my package',
    url='https://github.com/yourusername/my_package',  # Project URL
)
